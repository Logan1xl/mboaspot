package com.example.backend.roles;

public enum RoleUtilisateur {
    PROPRIETAIRE,
    ADMIN,
    VOYAGEUR

}
